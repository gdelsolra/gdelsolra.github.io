# gdelsolra.github.io

This repository hosts my CS 499 ePortfolio on **GitHub Pages**.

## Contents
- `index.html` – ePortfolio home
- `styles.css` – basic styles
- (Add artifacts, screenshots, and docs as I progress)

## Local preview
Just open `index.html` in a browser. On GitHub, Pages will deploy automatically to `https://gdelsolra.github.io/`.
